import React from 'react';
import type { VideoAnimations } from '../types';
export declare const Overlay: ({ animations: { AnimatedView, controlsOpacity }, }: {
    animations: VideoAnimations;
}) => React.JSX.Element;
