export declare const styles: {
    container: {
        alignSelf: "stretch";
        height: number;
        marginLeft: number;
        marginRight: number;
        marginBottom: number;
    };
    track: {
        backgroundColor: string;
        height: number;
        position: "relative";
        top: number;
        width: "100%";
        borderRadius: number;
    };
    fill: {
        backgroundColor: string;
        height: number;
        width: "100%";
        borderRadius: number;
    };
    handle: {
        position: "absolute";
        marginLeft: number;
        height: number;
        width: number;
    };
    circle: {
        borderRadius: number;
        position: "relative";
        top: number;
        left: number;
        height: number;
        width: number;
    };
};
