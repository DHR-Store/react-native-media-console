import React, { Dispatch, SetStateAction } from 'react';
import { GestureResponderHandlers } from 'react-native';
interface SeekbarProps {
    seekerFillWidth: number;
    seekerPosition: number;
    seekColor: string;
    cachedPosition: number;
    seekerPanHandlers: GestureResponderHandlers;
    setSeekerWidth: Dispatch<SetStateAction<number>>;
    time?: number;
    duration: number;
    showDuration: boolean;
    showTimeRemaining: boolean;
    showHours: boolean;
}
export declare const Seekbar: ({ seekColor, seekerFillWidth, seekerPosition, cachedPosition, seekerPanHandlers, setSeekerWidth, showDuration, showHours, showTimeRemaining, time, duration, }: SeekbarProps) => React.JSX.Element;
export {};
