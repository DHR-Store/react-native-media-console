import React from 'react';
interface LoaderProps {
    color?: string;
}
export declare const Loader: ({ color }: LoaderProps) => React.JSX.Element;
export {};
