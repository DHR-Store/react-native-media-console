import React from 'react';
interface FullscreenProps {
    isFullscreen: boolean;
    toggleFullscreen: () => void;
    resetControlTimeout: () => void;
    showControls: boolean;
}
export declare const Fullscreen: ({ isFullscreen, toggleFullscreen, resetControlTimeout, showControls, }: FullscreenProps) => React.JSX.Element;
export {};
