import React from 'react';
export declare const NullControl: () => React.JSX.Element;
