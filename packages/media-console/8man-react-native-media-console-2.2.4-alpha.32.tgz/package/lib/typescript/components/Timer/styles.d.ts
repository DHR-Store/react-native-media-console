export declare const styles: {
    timer: {
        maxWidth: number;
    };
    timerText: {
        backgroundColor: string;
        color: string;
        fontWeight: "600";
        fontSize: number;
    };
};
