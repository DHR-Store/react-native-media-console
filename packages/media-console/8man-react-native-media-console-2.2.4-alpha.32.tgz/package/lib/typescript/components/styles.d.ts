export declare const styles: {
    row: {
        flexDirection: "row";
        alignItems: "center";
        justifyContent: "space-between";
    };
    column: {
        flexDirection: "column";
        alignItems: "center";
        justifyContent: "space-between";
    };
    vignette: {
        resizeMode: "stretch";
    };
    control: {
        padding: number;
        opacity: number;
    };
    text: {
        backgroundColor: string;
        color: string;
        fontSize: number;
        fontWeight: "600";
        textAlign: "center";
    };
    seekBarContainer: {
        width: "100%";
    };
};
