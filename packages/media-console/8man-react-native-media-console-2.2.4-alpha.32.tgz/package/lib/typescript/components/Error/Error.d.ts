import React from 'react';
interface ErrorProps {
    error: boolean;
}
export declare const Error: ({ error }: ErrorProps) => React.JSX.Element | null;
export {};
