export declare const styles: {
    container: {
        position: "absolute";
        top: number;
        right: number;
        bottom: number;
        left: number;
        flexDirection: "row";
        alignItems: "center";
        justifyContent: "center";
        zIndex: number;
    };
    playContainer: {
        width: "35%";
        alignItems: "center";
    };
    play: {
        height: number;
        width: number;
    };
    rewind: {
        height: number;
        width: number;
    };
    forward: {
        height: number;
        width: number;
    };
};
