/// <reference types="node" />
import React from 'react';
type GesturesProps = {
    forward: (time?: number) => void;
    rewind: (time?: number) => void;
    togglePlayPause: () => void;
    seekerWidth: number;
    doubleTapTime: number;
    toggleControls: () => void;
    tapActionTimeout: React.MutableRefObject<NodeJS.Timeout | null>;
    tapAnywhereToPause: boolean;
    rewindTime: number;
    showControls: boolean;
    disableGesture: boolean;
    setPlayback: (rate: number) => void;
};
declare const Gestures: ({ forward, rewind, togglePlayPause, toggleControls, doubleTapTime, tapActionTimeout, tapAnywhereToPause, rewindTime, showControls, disableGesture, setPlayback, }: GesturesProps) => React.JSX.Element | null;
export default Gestures;
