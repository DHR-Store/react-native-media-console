import React from 'react';
interface TitleProps {
    primary: string;
    secondary?: string;
}
export declare const Title: (title: TitleProps) => React.JSX.Element | null;
export {};
