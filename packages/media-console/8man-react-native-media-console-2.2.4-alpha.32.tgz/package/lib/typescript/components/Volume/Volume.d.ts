import React from 'react';
import { GestureResponderHandlers } from 'react-native';
interface VolumeProps {
    volumeFillWidth: number;
    volumeTrackWidth: number;
    volumePosition: number;
    volumePanHandlers: GestureResponderHandlers;
    currentVolumePercentage?: number;
}
export declare const Volume: ({ volumeFillWidth, volumePosition, volumeTrackWidth, volumePanHandlers, currentVolumePercentage, }: VolumeProps) => React.JSX.Element;
export {};
