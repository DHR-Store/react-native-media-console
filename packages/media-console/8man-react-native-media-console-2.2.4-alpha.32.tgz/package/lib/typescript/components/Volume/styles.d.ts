export declare const styles: {
    container: {
        alignItems: "center";
        justifyContent: "flex-start";
        flexDirection: "row";
        height: number;
        marginLeft: number;
        marginRight: number;
        width: number;
    };
    track: {
        backgroundColor: string;
        height: number;
        marginLeft: number;
    };
    fill: {
        backgroundColor: string;
        height: number;
    };
    fillBoosted: {
        backgroundColor: string;
    };
    handle: {
        position: "absolute";
        marginTop: number;
        marginLeft: number;
        padding: number;
        zIndex: number;
    };
    icon: {
        marginLeft: number;
        width: number;
        height: number;
        resizeMode: "contain";
    };
    iconBoosted: {
        tintColor: string;
    };
    percentageText: {
        position: "absolute";
        right: number;
        color: string;
        fontSize: number;
        fontWeight: "bold";
    };
    textBoosted: {
        color: string;
    };
};
