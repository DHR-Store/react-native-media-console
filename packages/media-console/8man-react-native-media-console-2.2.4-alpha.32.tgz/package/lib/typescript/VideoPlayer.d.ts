import React from 'react';
import type { VideoPlayerProps } from './types';
export declare const VideoPlayer: (props: Omit<VideoPlayerProps, 'animations'>) => React.JSX.Element;
